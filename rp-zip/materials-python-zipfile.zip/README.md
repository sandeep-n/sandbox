# Sample Resources for Python's `zipfile`: Manipulate Your ZIP Files Efficiently

The `python-zipfile/` directory provides sample files for the tutorial [Python's zipfile: Manipulate Your ZIP Files Efficiently](https://realpython.com/python-zipfile/).

If you're following the tutorial, download the directory content to your local machine and place it in your favorite working directory.
